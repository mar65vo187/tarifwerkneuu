import { NextResponse, type NextRequest } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { advisors, employees } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { updateAccountSchema } from "@/lib/admin-validation";
import { accountSelection, adminFailure, AdminRequestError, authorizeAdmin, positiveId, readAdminJson } from "@/lib/admin-server";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function PATCH(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  try {
    const admin = await authorizeAdmin(request);
    if (admin instanceof NextResponse) return admin;
    const id = positiveId((await context.params).id);
    const parsed = updateAccountSchema.safeParse(await readAdminJson(request));
    if (!parsed.success) return NextResponse.json({ ok: false, error: parsed.error.issues[0]?.message ?? "Bitte die Eingaben prüfen." }, { status: 422 });
    const { advisor, password, ...account } = parsed.data;
    if (id === admin.id && (!account.active || account.role !== "admin")) throw new AdminRequestError("Der eigene Administratorzugang kann hier nicht deaktiviert oder herabgestuft werden.", 422);
    const passwordHash = password ? hashPassword(password) : undefined;
    const user = await db.transaction(async (tx) => {
      // Serialize role changes, so concurrent requests cannot remove the final administrator.
      await tx.execute(sql`select pg_advisory_xact_lock(746172, 2026)`);
      const [existing] = await tx.select(accountSelection).from(employees).where(eq(employees.id, id)).limit(1);
      if (!existing) throw new AdminRequestError("Benutzer nicht gefunden.", 404);
      if (existing.active && existing.role === "admin" && (!account.active || account.role !== "admin")) {
        const [row] = await tx.select({ count: sql<number>`count(*)::int` }).from(employees).where(and(eq(employees.active, true), eq(employees.role, "admin")));
        if (row.count <= 1) throw new AdminRequestError("Mindestens ein aktiver Administrator muss erhalten bleiben.", 422);
      }
      let advisorId = existing.advisorId;
      if (advisor) {
        if (advisorId) await tx.update(advisors).set({ ...advisor, name: account.name }).where(eq(advisors.id, advisorId));
        else {
          const [created] = await tx.insert(advisors).values({ ...advisor, name: account.name }).returning({ id: advisors.id });
          advisorId = created.id;
        }
      } else if (advisorId) {
        throw new AdminRequestError("Ein bestehendes Beraterprofil bleibt zugeordnet. Über „Profil öffentlich sichtbar“ kann es ausgeblendet werden.", 422);
      }
      const [updated] = await tx.update(employees).set({ ...account, advisorId, ...(passwordHash ? { passwordHash } : {}) }).where(eq(employees.id, id)).returning(accountSelection);
      return updated;
    });
    return NextResponse.json({ ok: true, user, signInAgain: id === admin.id && Boolean(password) });
  } catch (error) { return adminFailure(error); }
}
