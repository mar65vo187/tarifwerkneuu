# Prüfbericht – TarifWerk neu.zip

Stand: 15.09.2026. Grundlage ist die bereitgestellte neu.zip mit 92 Dateien. Die vorgefundene, unvollständige Reparatur wurde vervollständigt und gegen die Originaldateien abgeglichen.

## Nachgewiesen

- Produktionsbuild mit Next.js 16.2.6 und TypeScript erfolgreich, einschließlich aller API-, Portal- und öffentlichen Routen.
- ESLint: keine Fehler; zwei bestehende Hinweise zu nativen Logo-Bildern. Diese wurden wegen des Design-Erhalts nicht umgebaut.
- Fünf Authentifizierungs-Testgruppen bestanden: Passwortprüfung, manipulierte/abgelaufene Tokens, fehlende Geheimnisse, Cookie- und Kontostatus, Herkunftsprüfung.
- 16 Server-Integrationstestgruppen bestanden. Dafür wurden eine isolierte PGlite-Datenbank mit PostgreSQL-Protokoll und ein echter Next.js-Produktionsserver gestartet. Keine Kundendaten und keine produktiven Konten wurden verwendet.
- 21 öffentliche Seiten einschließlich aller acht Leistungsseiten, Beraterprofil, Suche, wiederholter Query-Parameter und Sitemap geprüft.
- Authentifizierte API-Aufrufe und Portal-HTML wurden geprüft. Sitzungen und gespeicherte Bilder überstehen einen Next.js-Serverneustart.

## Integrationstests

1. Migration installs empty database and repeats without changes
2. Explicit administrator setup is idempotent
3. Anonymous requests cannot access portal or administration; deep links are preserved
4. Case-insensitive login, persistent cookie and admin page
5. User and public profile created atomically; duplicate emails roll back
6. RBAC, self-demotion prevention and CSRF rejection
7. Multipart upload, real image decoding, durable storage, profile display and ETag
8. Corrupt images and unauthorized uploads rejected
9. Lead submission, confirmation validation, ownership and audit notes
10. Advisors cannot read applications or take another advisor’s assigned lead
11. Team chat saves and retrieves messages
12. 21 public pages, services, repeated query parameters, admin alias and genuine 404
13. Server restart preserves authenticated sessions and profile image storage
14. Password changes revoke existing sessions
15. Image removal clears both profile reference and stored data
16. Logout expires the session cookie

## Design- und Marketingabgleich

- index.html, alle ursprünglichen CSS-Dateien, Bilder und Schriften sind bytegleich zum Original.
- Alle 43 vorhandenen TSX-Dateien behalten ihre bisherigen className-, style-, Animations-, href-, src- und action-Attribute. Die neue Profilbildquelle ist die ausdrücklich ergänzte Uploadfunktion innerhalb des bestehenden Avatars.
- Marketinginhalte in src/lib/content.ts sowie bestehende Werbe-/Kontaktlinks bleiben unverändert.
- Die Benutzerverwaltung ist ein neuer geschützter Bereich, da eine solche Oberfläche in der ursprünglichen ZIP fehlte. Bestehende Seiten wurden nicht neu gestaltet.
- Bestehende Telefonnummernanzeige im Beraterprofil verwendet nun die Nummer des jeweiligen Beraters; Fehler-/Erfolgszustände verwenden vorhandene Flächen.

## Reparaturen

Datenbankmigration und explizite sichere Erstanlage; serverseitige Rollenprüfung; transaktionale Benutzer-/Berateranlage; eindeutige E-Mail-Adressen ohne Groß-/Kleinschreibungsabweichungen; Schutz aktiver Administratoren; signierte sitzungsübergreifende Cookies; Entwertung bei Passwortänderung; CSRF-Prüfung; begrenzte Request-Bodies; berechtigungsgesteuerte Lead-Listen und Details; konsistente Terminbestätigung; abgesicherte Multipart-Bildverarbeitung und persistente Bildspeicherung; korrigierte Formularzustände, Zeitlimits und Doppelklicksperren; Query-Parameter und Deep-Link-Rückkehr; mobile Menüereignisse und korrekte Button-Ref-/Linkweitergabe.

Eine zusätzliche direkte Abhängigkeit: sharp 0.34.5 zur vollständigen Bilddekodierung und Normalisierung. Sie war bereits transitiv installiert; keine weitere neue Laufzeitbibliothek.

## Noch nicht nachgewiesen / vor Livebetrieb erforderlich

- Keine Veröffentlichung auf tarifwerk.eu oder Sites. Eine produktive PostgreSQL-Verbindung, ein dauerhaftes Session-Geheimnis und ein eigenes Admin-Passwort müssen vom Betreiber gesetzt werden; es wurden keine Zugangsdaten erfunden.
- Keine vollständige Browserprüfung, kein gerenderter Pixelvergleich über alle Viewports, kein produktiver Last-/Mehrinstanztest. Der Designabgleich bezieht sich auf Dateien und Quellcodeattribute.
- PostgreSQL-kompatible Tests ersetzen nicht den Integrationstest gegen den konkreten produktiven Datenbankdienst und dessen TLS-/Proxy-Konfiguration.
- Die vollständige Geschäftsadresse fehlt im ursprünglichen Impressum. Sie muss vor einer Veröffentlichung ergänzt werden. Vorhandene Rechtstexte wurden nicht rechtlich geprüft oder geändert.
- Externe Telefon-, WhatsApp-, Werbe- und Trackingdienste wurden nicht umgestellt oder durch Testanfragen ausgelöst.

Eine absolute Fehlerfreiheits- oder Sicherheitsgarantie lässt sich aus diesen Prüfungen nicht ableiten. Details zu Einrichtung, Zugang und Betrieb stehen in quellcode/README.md.
