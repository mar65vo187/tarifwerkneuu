import { NextResponse, type NextRequest } from "next/server";

export function proxy(request: NextRequest) {
  const headers = new Headers(request.headers);
  // Always overwrite client input: only the actual portal URL is forwarded.
  headers.set("x-tarifwerk-portal-path", request.nextUrl.pathname + request.nextUrl.search);
  const response = NextResponse.next({ request: { headers } });
  response.headers.set("Cache-Control", "private, no-store");
  return response;
}

export const config = { matcher: ["/portal/:path*"] };
